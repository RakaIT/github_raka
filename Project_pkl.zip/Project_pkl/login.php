<?php
include "db.php";

session_start();

if (isset($_POST['login'])) {
    $u = $_POST['username'];
    $p = $_POST['password'];

    $login = $conn->query("SELECT * FROM author WHERE username = '$u' AND password = '$p'")->fetch_assoc();

    if ($login) {
        $_SESSION['user'] = $login;
        echo '<script>alert("Login Berhasil");
            location.replace("admin.php");</script>';
    } else {
        echo '<script>alert("Username atau Password tidak valid!");
            location.replace("");</script>';
    }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <title>Login | Form</title>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-lg-6">
                <form action="" method="post">
                    <div class="card">
                        <h1 class="card-header text-center">Login</h1>
                        <div class="card-body">
                            <label class="form-label" for="username">Username</label>
                            <input class="form-control" type="text" id="username" name="username" required placeholder="Masukan Username">
                            <label class="form-label" for="password">Password</label>
                            <input class="form-control" type="text" id="password" name="password" required placeholder="Masukan Password">
                            <button class="btn btn-primary w-100 mt-3" type="submit" name="login">Login</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>





    <script src="assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>