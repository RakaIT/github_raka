<?php
include '../db.php';

if (!isset($_GET['id'])){
    header('Location: ../index.php');
}else{
    $id = $_GET['id'];
    $artikel = $conn->query("SELECT * FROM artikel WHERE id = '$id'")->fetch_assoc();
}
if (isset($_POST['delete'])) {
    $articleId = $artikel['id'];

    $delete = $conn->query("DELETE FROM artikel WHERE id = $articleId");

    if ($delete) {
        echo '<script>alert("Data Berhasil dihapus");
        location.replace("../index.php");</script>';
    } else {
        echo '<script>alert("Data Gagal dihapus");
        location.replace("");</script>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
           body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            font-size: 14px;
        }

        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        p {
            margin-bottom: 10px;
            text-align: justify;
        }

        .author {
            font-style: italic;
        }
        .centered-image {
        max-width: 100%;
        max-height: 100%;
        display: block;
        margin: 0 auto;

        .article-title {
        white-space: normal; /* Memastikan teks judul dapat mencetak ke baris baru */
        word-break: break-word; /* Membuat kata-kata dapat mematahkan baris jika panjangnya melebihi lebar */
        text-align: center; /* Mengatur posisi judul menjadi tengah */
    }

    }
    </style>
    </style>
    <title>Tulis Artikel</title>
</head>

<body>
<nav class="navbar navbar-expand-lg shadow-sm py-3 ">
        <div class="container">
            <a class="navbar-brand" href="#">Huge</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav ms-auto">
                    <a class="nav-link mx-2 " href="../">Beranda</a>
                    <a class="nav-link mx-2 " href="../artikel/tulis-artikel.php">Unggah</a>
                    <a class="nav-link mx-2 acvtive" href="">View</a>
                    <a class="nav-link mx-2" href="#">contact me</a>
                </div>
            </div>
        </div>
    </nav>


    <div class="container">
    <h1 class="mt-4 article-title"><b><?= $artikel['Judul'] ?></b></h1>
        <hr>
        <img class="rounded-3 w-50 centered-image" src="../berkas/<?= $artikel['gambar'] ?>" alt="">
        <p class="author"><?= str_replace("\n", "<br>", $artikel['artikel']) ?></p>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card-body">
                 
                <form action="" method="POST" onsubmit="return confirm('Anda yakin ingin menghapus artikel ini?');"><a href="edit.php?id=<?= $artikel['id'] ?>" class="btn btn-secondary text-white btn-sm-4"> <i class="bi bi-pencil"></i> Edit Article</a>
                    <button type="submit" name="delete" id="submit" class="btn btn-primary">Delete this article</button>
                </form>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>