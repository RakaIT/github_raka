<?php
include "../db.php";



if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $profile = $conn->query("SELECT * FROM artikel WHERE id = $id")->fetch_assoc();
}


if (isset($_POST['update'])) {
    // Mengambil nilai dari inputan
    $penulis = $_POST['penulis'];
    $kategori = $_POST['kategori'];
    $Judul = $_POST['Judul'];
    $konten = $_POST['konten'];
    $direktori = "../berkas/";

    // Mengecek apakah ada gambar yang diunggah
    if ($_FILES['gambar']['name'] != '') {
        $gambar = $_FILES['gambar']['name'];
        $target_file = $direktori . $gambar;
        $ext = pathinfo($target_file, PATHINFO_EXTENSION);

        $allowed_extensions = array('jpg', 'jpeg', 'png');

        if (!in_array($ext, $allowed_extensions)) {
            // Kode validasi gambar jika ekstensi tidak sesuai
        } else {
            move_uploaded_file($_FILES['gambar']['tmp_name'], $direktori . $gambar);
        }
    } else {
        // Jika tidak ada gambar yang diunggah, gunakan alamat gambar lama
        $gambar = $profile['gambar'];
    }

    // Melakukan update ke database dengan gambar baru atau lama
    $update = $conn->query("UPDATE artikel SET penulis = '$penulis', kategori = '$kategori', Judul = '$Judul', artikel = '$konten', gambar = '$gambar' WHERE id = '$id' ");


    if ($update == true) {
        echo '<script>alert("Data Berhasil diupdate");
        location.replace("../index.php");</script>';
    } else {
        echo '<script>alert("Data Gagal diupdate");
        location.replace("");</script>';
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <title>Tulis Artikel</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg shadow-sm py-3">
        <div class="container">
            <a class="navbar-brand" href="#">Huge</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav ms-auto">
                    <a class="nav-link mx-2 disabled" href="#">Beranda</a>
                    <a class="nav-link mx-2 active" href="#">Ubah</a>
                    <a class="nav-link mx-2 disabled" href="#">View</a>
                </div>
            </div>
        </div>
    </nav>


    <div class="container">
        <h1 class="mt-4">Upload Artikel</h1>
        <hr>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="penulis">Penulis:</label>
                        <input type="text" class="form-control" name="penulis" value="<?= $profile['penulis'] ?>" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="kategori">Kategori:</label>
                        <input type="text" class="form-control" name="kategori" value="<?= $profile['kategori'] ?>"
                            required>
                    </div>
                </div>
            </div>
            <!-- <div class="form-group mb-3">
                <label for="tanggal_publish">tanggal_publish Artikel:</label>
                <input type="date" class="form-control" name="tanggal_publish" required>
            </div> -->
            <div class="form-group mb-3">
                <label for="Judul">Judul Artikel:</label>
                <input type="text" class="form-control" name="Judul" value="<?= $profile['Judul'] ?>" required>
            </div>
            <div class="form-group mb-3">
                <label for="konten">Konten Artikel:</label>
                <textarea id="konten" class="form-control" name="konten" rows="10"
                    required><?= $profile['artikel'] ?></textarea>
            </div>
            <div class="form-group mb-3">
                <label for="gambar">Gambar:</label>
                <input type="file" class="form-control-file" name="gambar" id="gambar">
            </div>
            <div class="text-end mb-3">
                <button type="submit" name="update" id="update" class="btn btn-primary">Update Artikel <i
                        class="bi bi-cloud-arrow-up"></i></button>
                <button type="" class="btn btn-warning"> <a href="view.php">Batalkan</a></button>
            </div>
        </form>
    </div>

    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script>

    </script>
</body>

</html>