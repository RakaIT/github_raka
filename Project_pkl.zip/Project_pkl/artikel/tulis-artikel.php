<?php

include "../db.php";

if (isset($_POST['submit'])) {
    $penulis = $_POST['penulis'];
    $tanggal_publish = date('Y-m-d');
    $kategori = $_POST['kategori'];
    $Judul = $_POST['Judul'];
    $konten = $_POST['konten'];
    $direktori = "../berkas/";
    $gambar = $_FILES['gambar']['name'];
    $target_file = $direktori . $gambar;
    $ext = pathinfo($target_file, PATHINFO_EXTENSION);

    $allowed_extensions = array('jpg', 'jpeg', 'png');
    if (!in_array($ext, $allowed_extensions)) {
        //   echo '<script>alert("Data Gagal diupdate");
        //       </script>';
    } else {
        move_uploaded_file($_FILES['gambar']['tmp_name'], $direktori . $gambar);
        $submit = $conn->query("INSERT INTO artikel VALUES (NULL,'$Judul','$konten', '$tanggal_publish', '$penulis', '$kategori' ,'$gambar')");

        if ($submit) {
            echo '<script>alert("Data Berhasil disimpan");
            location.replace("../index.php");</script>';
        } else {
            echo '<script>alert("Data Gagal disimpan");
            location.replace("");</script>';
        }
    }

    // // Mengambil data dari form
    // $judul = $_POST['judul'];
    // $konten = $_POST['konten'];

    // // Mengunggah gambar ke folder yang diinginkan
    // $targetDir = "path/to/uploaded_images/";
    // $gambar = basename($_FILES["gambar"]["name"]);
    // $targetPath = $targetDir . $gambar;
    // move_uploaded_file($_FILES["gambar"]["tmp_name"], $targetPath);

    // // Proses penyimpanan data artikel ke dalam database
    // // Lakukan sesuai dengan library/database yang Anda gunakan (misalnya MySQLi, PDO, atau ORM)

    // // Tampilkan pesan sukses atau error
    // if ($uploadSukses) {
    //     echo "Artikel berhasil diupload.";
    // } else {
    //     echo "Terjadi kesalahan saat mengupload artikel.";
    // }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <title>Tulis Artikel</title>
</head>

<body>
<nav class="navbar navbar-expand-lg shadow-sm py-3">
        <div class="container">
            <a class="navbar-brand" href="#">Huge</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav ms-auto">
                    <a class="nav-link mx-2 " href="../">Beranda</a>
                    <a class="nav-link mx-2 active" href="#">Unggah</a>
                    <a class="nav-link mx-2 disabled" href="">View</a>
                    <a class="nav-link mx-2" href="#">contact me</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <h1 class="mt-4">Upload Artikel</h1>
        <hr>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="penulis">Penulis:</label>
                        <input type="text" class="form-control" name="penulis" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="kategori">Kategori:</label>
                        <input type="text" class="form-control" name="kategori" required>
                    </div>
                </div>
            </div>
            <!-- <div class="form-group mb-3">
                <label for="tanggal_publish">tanggal_publish Artikel:</label>
                <input type="date" class="form-control" name="tanggal_publish" required>
            </div> -->
            <div class="form-group mb-3">
                <label for="Judul">Judul Artikel:</label>
                <input  type="text" class="form-control" name="Judul" required>
            </div>
            <div class="form-group mb-3">
                <label for="konten">Konten Artikel:</label>
                <textarea id="konten" class="form-control" name="konten" rows="10" required></textarea>
            </div>
            <div class="form-group mb-3">
                <label for="gambar">Gambar:</label>
                <input type="file" class="form-control-file" name="gambar" required>
            </div>
            <div class="text-end mb-3">
                <button type="submit" name="submit" id="submit" class="btn btn-primary">Upload</button>
            </div>
        </form>
    </div>

    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script>

    </script>
</body>

</html>