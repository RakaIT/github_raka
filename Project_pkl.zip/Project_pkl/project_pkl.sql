-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 15 Jun 2023 pada 11.21
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_pkl`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `artikel`
--

CREATE TABLE `artikel` (
  `id` int(11) NOT NULL,
  `Judul` varchar(255) NOT NULL,
  `artikel` text NOT NULL,
  `tanggal_publikasi` date NOT NULL,
  `penulis` varchar(255) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `artikel`
--

INSERT INTO `artikel` (`id`, `Judul`, `artikel`, `tanggal_publikasi`, `penulis`, `kategori`, `gambar`) VALUES
(5, 'gatau mang eak', 'Kami adalah Perusahaan Harga Karpet Futsal Jakarta yang menjual Karpet Sintetis Futsal, Karpet Rumput Futsal, Rumput Sintetis Lapangan Futsal, Rumput Sintetis Lapangan Bola, Rumput Untuk Futsal\r\n\r\nGaransi Uang Kembali jika produk tidak sesuai dengan Harapan\r\n\r\nJika Anda Berminat Bisa Hubungi Kami di Nomor :\r\nhttps://wa.me/6281318883437\r\n\r\n\r\nDaftar Isi:\r\n \r\n\r\nApakah yang dimaksud dengan Rumput Futsal \r\nRumput Futsal dibentuk seperti serat sintetis serta dibuat biar mirip rumput asli. Semula rumput ini umumnya dipakai buat beberapa kebutuhan olahraga, seperti lapangan hijau pada olahraga sepak bola, futsal serta minisoccer.\r\n\r\nBerapakah Luas Lapangan Futsal? \r\nUkuran Lapangan Futsal Standard Nasional \r\nDilansir dari suatu modul dengan tajuk Standard Ukuran Lapangan Futsal dari KFI Sport, ukuran lapangan futsal standard nasional punyai panjang di antara 25 mtr. s/d 42 mtr.. Dalam pada itu, buat lebarnya kurang lebih 15 s/d 25 mtr.\r\n\r\nGambar Lapangan Futsal Rumput Sintetis\r\n\r\nkarpet futsal jakarta rumput produksi yang dibuat dari serat sintetis maka dari itu mirip wujud serta warna rumpu aslinya. Rumput ini dipakai buat pekerjaan olahraga.\r\n\r\nJenis Rumput Sintetis Lapangan Futsal\r\nKalaupun Anda merupakan jenis orang yang tidak demikian memahami berkaitan kualitas dari rumput futsal sintetis, pasti buat memutuskan karpet dengan kualitas terbagus tidak seringan yang dipikirkan. Tapi, Anda dapat memutuskan rumput sintetis lapangan futsal berbahan produksi yang punyai penampilan yang lebih alami.\r\n\r\nDisamping dapat disaksikan dari penampakannya, ada juga sejumlah faktor yang dapat pengaruhi dari kualiatas rumput futsal lapangan futsal. Sejumlah faktor itu merupakan berkaitan sensitas, struktur, serta ada atau tidaknya lubang pada rumput sintetis ini. Nach, buat rumput lapangan futsal yang punyai density yang baik, tentulah memberikan indikasi jumlahnya serat yang terdapat sangatlah baik.\r\n\r\nBuat struktur, upayakan memperoleh rumput futsal lapangan futsal yang punyai struktur yang halus. Jangan sekali memutuskan rumput futsal yang bertektur kasar. Bertambah halus rumput sintetis yang Anda putuskan, karena itu bertambah memiliki kualitas juga rumpu sintetis yang Anda perolehp penting diketahui, kalau rumput sintetis yang punyai density yang tinggi membikin berat rumput lebih menjadi berat. Type rumput sintetis ini disamping dapat dipakai buat lapangan futsal, sangat sesuai ditempatkan dipekarangan. Namun, kalau dana yang Anda miliiki begitu terbatas, karena itu Anda dapat memutuskan rumput type rumput sintetis lapangan futsal yang punyai density yang rendah. Pasalnya rumput sintetis lapangan futsal yang punya density yang rendah di bandrol pada harga yang murah.\r\n\r\nMacam Macam karpet futsal jakarta\r\nAda empat type rumput yang sering dipakai buat lapangan sepak bola sama sesuai standard internasional.\r\nEmpat type rumput lapangan sepak bola merupakan\r\n\r\n•	 Zoysia Matrella,\r\n•	 Cydodon Dactylon,\r\n•	 Axonopus Compressus, serta\r\n•	 Sintetis.\r\n\r\nRumput lapangan yang bagus bisa membikin pemain sepak bola tampilkan permainan permainan cantiknya.\r\n\r\nMau tau? Harga karpet futsal jakarta\r\nHarga karpet futsal Jakarta lapangan futsal / sepak bola berkisar Rp 150.000 - 250.000 per m. Biaya pemasangan rumput sintetis lapangan futsal Rp 90.000.000 - Rp 150.000.000. Adapun biaya untuk instalasi di lapangan sepak bola Rp 1,5 miliar - 2,5 miliar yang dikerjakan selama 3 - 4 bulan. Biaya pembangunan lapangan sepak bola lebih mahal karena lebih luas daripada lapangan futsal. Spesifikasinya pun bermacam-macam, seperti menambahkan pasir dan karet pasir guna meredam pantulan bola.\r\n\r\nBerapa biaya pembuatan lapangan futsal?\r\nModal Bisnis Lapangan Futsal\r\n\r\nBiaya konstruksi tiang baja Rp 150.000.000 - Rp 200.000.000. Biaya rumput futsal sintetis Rp 50.000.000 - 55.000.000. Biaya pembangunan pondasi dan lantai Rp 100.000.000 - Rp 110.000.000. Biaya jaring, lampu dan bola Rp 10.000.000 - Rp 15.000.000. Untuk Pemesanan Bisa Langsung Whats App ke : 0813-1888-3437\r\n\r\nLayanan Kami:\r\n•	 Karpet Futsal Rumput\r\n•	 Sintetis Rumput Futsal\r\n•	 Rumput Sintetis Lapangan Sepak Bola\r\n•	 Rumput Futsal Sintetis\r\n•	 Rumput Sintetis Futsal\r\n•	 Keset Rumput Futsal\r\n•	 Rumput Karpet Futsal\r\n•	 Rumput Untuk Lapangan Futsal\r\n•	 Rumput Lapangan Futsal\r\n•	 Karpet Lapangan Futsal\r\n•	 Karpet Futsal Rumput Sintetis\r\n\r\n#rumputplastiklapanganfutsalrumputlapanganfutsaltangerang #rumputlapanganfutsalmurahrumputsintetislapanganfutsal #rumputsintetisminisoccerrumputfutsalchina #rumputsintetisfutsalmurahrumputsintetisfutsaldibekasi #rumputuntuklapanganfutsalrumputfutsalmurahbandung #sintetisrumputfutsalrumputlantaifutsal #karpetlapanganfutsalbandungrumputsintetisuntukfutsal #rumputlantaifutsalrumputsintetislapanganbola #rumputgolffutsalkarpetsintetisfutsal #rumputsintetisfutsaloutdoorrumputgolf\r\n', '2023-05-31', 'aku jawir', 'komedi', 'coding-screen.jpeg'),
(7, 'inijnijn', 'jnjnjonjonjn', '2023-05-31', 'astagfirullah ukhty', 'jnijn', 'RobloxScreenShot20221213_212427961.png'),
(12, 'iluashdflaiuhe', 'aiuldhfa;erfajirhvaufhajxo8hmglugoufygasoudfgqugeawtsssssssssssssssssssssrrdyyufyfyyfiugogcguihogfreryfykhl', '2023-06-02', 'aisbkahebfawfsahsfb', 'aisudhailusd', 'besi.jpg'),
(13, 'BARANG SELALU READY, Tlp 0822-9867-5016 Rekomendasi Yang Jual Karpet Bulutangkis Bandung', 'Kami adalah Perusahaan Rekomendasi Yang Jual Karpet Bulutangkis Bandung yang melayani Carpet Gelanggang Badminton, Karpet Bulutangkis Bandung, Karpet Badminton Court, Karpet Badminton Banten, Lantai Untuk Lapangan Badminton\r\n\r\n\r\n\r\n\r\n\r\nYuk Kenalan dengan Kontraktor Futsal Indonesia https://www.kontraktorfutsalindonesia.com/\r\n\r\nUntuk alamat lengkap perusahaan kami bisa cek di Google Map\r\nAlamat: Kantor KFI Sport, Jl. Masjid Rw. Bacang, RT.08/RW.014, Jatirahayu, Kec. Pd. Melati, Kota Bks, Jawa Barat 17414\r\nhttps://goo.gl/maps/jFCguo1xhi2RBTth9\r\n\r\n\r\nDaftar Isi:\r\nYuk Kenalan dengan Kontraktor Futsal Indonesia https://www.kontraktorfutsalindonesia.com/\r\n\r\nUntuk alamat lengkap perusahaan kami bisa cek di Google Map\r\nAlamat: Kantor KFI Sport, Jl. Masjid Rw. Bacang Ruko No R2, RT.08/RW.014, Jatirahayu, Kec. Pd. Melati, Kota Bks, Jawa Barat 17414\r\nhttps://goo.gl/maps/jFCguo1xhi2RBTth9\r\n\r\nKeunggulan vinyl lainnya adalah mampu menyerap pantulan cahaya dari atas atau berbagai sisi lainnya. Sehingga, pemain tidak merasa silau ketika bertanding. Dalam ajang resmi BWF, warna karpet sintetis lapangan bulu tangkis bisa berbagai macam mulai dari hijau, biru, dan merah.\r\n\r\nCara Pasang Karpet Badminton\r\nBeberapa proses pemasangan yang wajib anda ketahui agar anda puas dengan kinerja kami, antara lain:\r\n1. Lakukan Konsultasi Terlebih Dahulu\r\nProses pemasangan karpet lantai bulutangkis diawali dengan melakukan konsultasi terlebih dahulu agar kami tahu apa kebutuhan dan keinginan anda sehingga kami bisa memberikan solusi terbaik atas masalah yang mungkin dialami.\r\n\r\n2. Pengecekan Area yang Akan Dipasang\r\nPengecekan tempat dilakukan untuk mengetahui seberapa sulit medan yang akan kami kerjakan sehingga sudah bisa diantisipasi sejak dini. Dengan memahami medan, proses pengerjaan pun bisa berjalan dengan lancar.\r\n\r\n3. Pemilihan Bahan yang Tepat\r\nSelanjutnya pemilihan bahan yang tepat harus diperhatikan agar hasilnya sesuai dengan keinginan dan bisa meningkatkan kenyamanan saat bermain bulutangkis. Anda bisa memilih sendiri ataupun mengikuti rekomendasi dari tim kami. Pilihan bahannya antara lain:\r\n+ Crystal Sand\r\n+ Gems\r\n+ Training Gems\r\n+ Training Crystal Sand\r\n+ Snake Skin\r\n+ Liche\r\n+ Coral\r\n\r\n4. Proses Pengerjaan\r\nPengerjaan dilakukan dengan membuat rencana kerja terlebih dahulu. Jika semua persiapan sudah selesai dilakukan, pengaplikasian langsung ke tempatnya akan segera kami lakukan sesuai dengan jadwal yang sudah disepakati. Dalam waktu kurang lebih hanya 4 jam saja, kami akan segera menyelesaikan lapangan bulutangkis yang anda pesan.\r\n\r\n5. Quality Control\r\nTahapan terakhir yang akan tim kami lakukan adalah dengan melakukan pengecekan final (Quality Control) untuk memastikan tidak terjadi masalah pada karpet lapangan badminton yang kami kerjakan. Selain itu anda juga akan mendapatkan garansi selama 30 hari khusus untuk bagian sambungan yang terlepas atau pun rekatan yang tidak sempurna.\r\n\r\nCara pasang karpet lapangan bulutangkis di atas yang sudah memenuhi standar internasional tentu akan membawa keuntungan bagi anda. Segera pesan dan buktikan sendiri kualitasnya.\r\n\r\nKeunggulan Bahan Karpet Sintetis Untuk Bulu Tangkis\r\nBahan karpet sintetis dari vinyl sangat fleksibel untuk digulung dan pasang ulang di tempat yang datar. Selain itu, karpet sintetis lapangan dari vinyl punya daya cengkeram yang kuat sehingga tidak licin untuk sepatu badminton.\r\n\r\nSpesifikasi Karpet Lapangan Badminton Yang Banyak Diminati Saat ini\r\n+ 1 lapangan 4 roll dan 1 roll ukuran ( 1.8m x 15m ) dan tentu dalam luas satu lapangan 108m2 dan tentu sudah termasuk material pemasangan karpet badminton.\r\n\r\nMaterial Pendukung untuk lapangan badminton yakni :\r\n+ 1 welding rood\r\n+ Include Jasa Pemasangan Karpet Badminton\r\n\r\nPerlu diperhatikan produk yang kami hanya produk original yang tentu nya dengan produk vinyl lapangan badminton yang bagus dan berkualitas tinggi maka dianjurkan anda bisa tanya mengenai informasi seputar karpet lapangan bulutangkis disini.\r\n\r\nPengiriman Menggunakan Pick up untuk 1 lapangan karena bobot yang sangat berat per roll nya.\r\n\r\nSebelum Anda Membeli diHaruskan Untuk Mengetahui Terlebih Dahulu Penjelasan Kami dari Barang dikirim Hingga Pada Proses Pemasangan Karpet lapangan badminton agar kondisi yang akan anda terima sudah jadi terpasangan dan juga siap digunakan di gor lapangan bulutangkis yang anda miliki.\r\n\r\nDan Kami Juga menerima skala pemesanan besar seperti sekali order dengan jumlah 10 lapangan badminton atau lebih dan siap kirim ke seluruh wilayah Indonesia dan sekitar nya.\r\n\r\nUkuran Karpet Badminton\r\nUkuran yang diperlukan yaitu 7,5meter x 14,5meter untuk keseluruhan pasang 1 lapangan badminton.\r\n\r\nJenis Karpet Lapangan Badminton Yang Dijamin Kualitasnya\r\nAda beberapa jenis karpet badminton yang terkenal dan juga kami sediakan, diantaranya karpet badminton Flypower, Yonex, Lining, Alite. Merk merk tersebut terkenal memiliki harga yang cukup mahal sehingga anda bisa mempertimbangkan merk lain untuk menyesuaikan budget yang anda miliki. Merk karpet badminton lain contohnya Alite, Benow, Enlio.\r\n\r\nMau tau? Harga Karpet Lapangan Badminton Terbaik\r\nJIka anda berminat bisa segera Hubungi Kami Di No : 0822.9867.5016\r\n\r\nLayanan Kami:\r\n- Pelapis Lantai Lapangan Badminton\r\n- Karpet Lapangan Badminton Terbaik\r\n- Karpet Lapangan Badminton Flypower\r\n- Lantai Lapangan Bulu Tangkis\r\n- Karpet Badminton Baru\r\n- Karpet Untuk Badminton\r\n- Karpet Badminton Bekasi\r\n- Karpet Lapangan Badminton Yonex\r\n- Lantai Karpet Lapangan Badminton\r\n- Carpet Court Badminton\r\n- Karpet Badminton Flypower\r\n\r\n#karpetlapanganbadmintonmurahcarpetgelanggangbadminton #karpetlapanganbadmintonflypowerlantaikarpetbadmintonsurabaya #lantaikarpetbadmintonsurabayakarpetbulutangkisbandung #karpetbadmintonyonexkarpetgelanggangbadminton #karpetlapanganbadmintonmerahkarpetlapanganbadmintonmurah #karpetvinylbadmintonlantailapanganbadminton #karpetgelanggangbadmintonkarpetlapanganbadmintondanharga #lantailapanganbadmintonkarpetbadmintonlining #karpetbadmintonjakartakarpetbadmintonmurah #karpetbadmintonlantaiuntuklapanganbadminton', '2023-06-06', 'Muhammad Putra Rizaldi', 'PROJECT', 'besi.jpg');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `artikel`
--
ALTER TABLE `artikel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
