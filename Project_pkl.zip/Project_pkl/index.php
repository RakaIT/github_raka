<?php
include 'db.php';

$artikels = $conn->query("SELECT * FROM artikel");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .banner-gradient {
            height: 100px;
            width: 100%;
            /* background: rgb(64, 244, 236);
            background: linear-gradient(90deg, rgba(64, 244, 236, 1) 2%, rgba(0, 0, 0, 1) 95%); */
            background: rgb(64, 244, 236);
            background: linear-gradient(90deg, rgba(64, 244, 236, 1) 2%, rgba(0, 0, 0, 0.6098360655737705) 95%);
        }
    </style>
    <title>Beranda</title>
</head>

<body>

    <!-- bagian navbar -->

    <nav class="navbar navbar-expand-lg shadow-sm py-3">
        <div class="container">
            <a class="navbar-brand" href="#">Huge</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav ms-auto">
                    <a class="nav-link mx-2 active" href="#">Beranda</a>
                    <a class="nav-link mx-2" href="artikel/tulis-artikel.php">Unggah</a>
                    <a class="nav-link mx-2 disabled" href="">View</a>
                    <a class="nav-link mx-2" href="#">contact me</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- bagian isi -->

    <div class="banner-gradient"></div>

    <div class="container mt-3">
        <div class="row gy-4">
            <?php foreach ($artikels as $artikel): ?>
                <div class="col-md-6">
                    <a class="text-decoration-none text-dark" href="artikel/view.php?id=<?= $artikel['id'] ?>">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6" style="height:150px">
                                        <div class="d-flex h-100 flex-column">
                                            <div class=" mb-auto">
                                                <p class="m-0">
                                                    <?= substr($artikel['penulis'], 0, 30) ?>
                                                </p>
                                                <h4 class="fw-bold">
                                                    <?= substr($artikel['Judul'], 0, 20) ?>
                                                </h4>
                                                <p>
                                                    <?= substr($artikel['artikel'], 0, 30) ?>
                                                </p>
                                            </div>
                                            <div class="d-inline">
                                                <span>
                                                    <?= date('M d', strtotime($artikel['tanggal_publikasi'])) ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <img class="rounded-3 w-100" src="berkas/<?= $artikel['gambar'] ?>" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach ?>
        </div>
    </div>




    <script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>